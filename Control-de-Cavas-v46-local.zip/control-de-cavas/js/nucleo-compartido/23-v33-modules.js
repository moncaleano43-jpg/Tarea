
/* ============================================================
   v33 — Cifra más intuitivo: conoce la base de datos de levadura y
   distingue lo que YA SE USÓ, lo que está EN PROCESO ahora y lo que
   está DISPONIBLE en colectores. Familias, generaciones, linaje y
   estados, con seguimiento de la conversación.
   ============================================================ */
(function(){
  if(!window.App||!App.V31||!App.BotDirecto||!App.BDM) return;
  const {esc,fmtS,f,parseDT}=App.U, V=App.V31, rel=(t,n)=>App.C.rel(t,n||Date.now());
  const {tit,hl,pct}=V, BDM=App.BDM, prev=App.BotDirecto;
  const pend=()=>App.D.pend(Date.now());
  const MARCA_PAL={estandar:"ESTANDAR",light:"LIGHT",azteca:"AZTECA",aguila:"AGUILA",pilsen:"PILSEN","club colombia":"CLUB COLOMBIA",club:"CLUB COLOMBIA"};
  const RE_MARCA=/\b(estandar|light|azteca|aguila|pilsen|club colombia|club)\b/;
  const parse=n=>{ try{ return BDM.parseNombre(n)||{}; }catch(e){ return {}; } };
  const plural=(n,s,p)=>n===1?s:p;
  const lst=V.lst;
  const fixTypos=t=>String(t||"").replace(/\bfam[a-z]{1,3}lia\b|\bfamlia\b|\bfamila\b/gi,"familia").replace(/\b(?:g|j)ener[a-z]{2,5}n(es)?\b/gi,m=>/es$/i.test(m)?"generaciones":"generacion");
  const Q=t=>V.norm(fixTypos(t));

  /* ---------- Datos: qué se usó, qué está en proceso, qué hay en colectores ---------- */
  function datos(){ const now=Date.now(), P=pend(), lotesAct=new Set(P.map(x=>x.t.lote));
    const REG=(BDM.registros()||[]).filter(r=>r.nombre&&r.estadoRegistro!=="anulado");
    const enTanque=P.map(x=>{ const L=x.t.levadura||{}, pn=parse(L.nombre); return {tq:+x.t.tq,lote:x.t.lote,nombre:L.nombre,gen:+L.generacion,fam:pn.fam,marca:pn.marca,st:x.st,r:x.r,x}; }).filter(o=>o.nombre);
    const enCol=[]; [1,2,3,4,5,6].forEach(n=>[1,2].forEach(s=>{ const c=App.S.colectores[`c${n}-${s}`]; if(!c) return; const pn=parse(c.nombre); enCol.push({pos:`C${n}-P${s}`,nombre:c.nombre,gen:+c.generacion,fam:pn.fam,marca:pn.marca,vol:c.vol,c}); }));
    return {now,REG,lotesAct,enTanque,enCol}; }
  const padre=(D,r)=>D.REG.find(p=>p.id!==r.id&&(p.siembras||[]).some(s=>s.lote===r.lote));
  const fvTxt=(D,tq,lote)=>D.lotesAct.has(lote)?`<a href="#/tanque/${esc(lote)}">FV ${tq}</a>`:`FV ${tq}`;
  const estadoTxt=st=>({utilizada:"ya utilizada",inventario:"disponible en colector",vaciada:"vaciada sin resiembra",descartada:"descartada",incompleto:"registro incompleto",sincol:"sin colector"}[st]||st);
  const marcaTxt=m=>m?tit(m):"";
  function tanquesUnicos(sie,max=30){ const m=new Map(); sie.forEach(s=>m.set(s.tq,(m.get(s.tq)||0)+1)); const a=[...m.entries()].map(([tq,n])=>n>1?`FV ${tq} ×${n}`:`FV ${tq}`); return {n:m.size,txt:compacto(a,max)}; }
  function compacto(a,max=24){ return a.length>max?a.slice(0,max).join(", ")+` y ${a.length-max} más`:a.join(", "); }

  /* ---------- Familia ---------- */
  function familia(D,fam,marca){ fam=fam.toUpperCase();
    const R=D.REG.filter(r=>String(r.familia).toUpperCase()===fam&&(!marca||r.marca===marca));
    if(!R.length) return {h:`No encuentro la familia <b>${esc(fam)}</b>${marca?" de "+esc(tit(marca)):""} en la base de datos.`};
    const marcas=[...new Set(R.map(r=>r.marca))].filter(Boolean).sort((a,b)=>R.filter(r=>r.marca===b).length-R.filter(r=>r.marca===a).length);
    const bloques=marcas.map(m=>{ const rs=R.filter(r=>r.marca===m), gens=rs.map(r=>+r.generacion).filter(g=>!isNaN(g)), gMin=Math.min(...gens), gMax=Math.max(...gens);
      const proceso=D.enTanque.filter(o=>o.fam===fam&&o.marca===m), cols=D.enCol.filter(o=>o.fam===fam&&o.marca===m);
      const sie=[]; rs.forEach(r=>(r.siembras||[]).forEach(s=>sie.push({tq:+s.tq,lote:s.lote,fecha:s.fecha,nombre:r.nombre,gen:+r.generacion})));
      const hechas=sie.filter(s=>!D.lotesAct.has(s.lote)).sort((a,b)=>String(b.fecha).localeCompare(String(a.fecha)));
      const util=rs.filter(r=>r.st==="utilizada").length, desc=rs.filter(r=>r.st==="descartada").length, vac=rs.filter(r=>r.st==="vaciada").length;
      const ult=rs.slice().sort((a,b)=>String(b.t0).localeCompare(String(a.t0)))[0];
      return `<div class="v33-b"><b>Familia ${esc(fam)} · ${esc(tit(m))}</b> — ${rs.length} ${plural(rs.length,"cosecha","cosechas")} · Gen ${gMin}${gMax!==gMin?"–"+gMax:""}
        <br><span class="v33-k">Ya se usó:</span> ${hechas.length?(()=>{ const u=tanquesUnicos(hechas); return `${hechas.length} ${plural(hechas.length,"siembra terminada","siembras terminadas")} en <b>${u.n}</b> ${plural(u.n,"tanque","tanques")}: ${u.txt}.`; })():"todavía no tiene siembras terminadas."}${util||desc||vac?` <small>(${util} utilizadas${desc?", "+desc+" descartadas":""}${vac?", "+vac+" vaciadas sin resiembra":""})</small>`:""}
        <br><span class="v33-k">En proceso ahora:</span> ${proceso.length?lst(proceso.map(o=>`${fvTxt(D,o.tq,o.lote)} (${esc(o.nombre)}, Gen ${o.gen})`))+".":"ninguno."}
        <br><span class="v33-k">En colectores:</span> ${cols.length?lst(cols.map(o=>`${o.pos} ${esc(o.nombre)} (Gen ${o.gen}, ${hl(o.vol)})`))+".":"nada por ahora."}
        ${ult?`<br><small>Última cosecha: ${esc(ult.nombre)}${ult.t0?" el "+fmtS(parseDT(ult.t0)):""}.</small>`:""}</div>`; });
    const activas=[...new Set(D.enTanque.concat(D.enCol).map(o=>o.fam&&o.marca?o.fam+"|"+o.marca:null).filter(Boolean))].filter(k=>k.split("|")[0]!==fam).slice(0,3);
    return {h:bloques.join(""),opts:activas.map(k=>{ const [fa,ma]=k.split("|"); return {label:`Familia ${fa} · ${tit(ma)}`,q:`familia ${fa} ${ma.toLowerCase()}`}; }),mem:{tipo:"familia",fam,marca}}; }

  /* ---------- Generaciones que hay ahora ---------- */
  function generacionesAhora(D,soloGen){
    const mapa={}; const get=g=>mapa[g]||(mapa[g]={g,t:[],c:[]});
    D.enTanque.forEach(o=>{ if(!isNaN(o.gen)) get(o.gen).t.push(o); }); D.enCol.forEach(o=>{ if(!isNaN(o.gen)) get(o.gen).c.push(o); });
    let gens=Object.values(mapa).sort((a,b)=>a.g-b.g); if(soloGen!=null) gens=gens.filter(x=>x.g===+soloGen);
    if(!gens.length) return {h:soloGen!=null?`Ahora mismo <b>no tienes ninguna levadura de Gen ${soloGen}</b> ni en fermentación ni en colectores.`:"No hay levadura en fermentación ni en colectores."};
    const nT=D.enTanque.length, nC=D.enCol.length;
    const linea=x=>{ const nom={}; x.t.forEach(o=>{ (nom[o.nombre]=nom[o.nombre]||{t:[],c:[]}).t.push(o); }); x.c.forEach(o=>{ (nom[o.nombre]=nom[o.nombre]||{t:[],c:[]}).c.push(o); });
      const tot=x.t.length+x.c.length; return `<div class="v33-g"><b>Gen ${x.g}</b>: ${tot} ${plural(tot,"unidad","unidades")} <small>(${x.t.length} en fermentación · ${x.c.length} en colector)</small><br><small>${Object.entries(nom).map(([n,o])=>`${esc(n)} → ${[...o.t.map(q=>fvTxt(D,q.tq,q.lote)),...o.c.map(q=>q.pos)].join(" + ")}`).join(" · ")}</small></div>`; };
    const cab=soloGen!=null?"":`Ahora tienes <b>${nT+nC}</b> ${plural(nT+nC,"unidad","unidades")} de levadura: <b>${nT}</b> en fermentación (FV) y <b>${nC}</b> en colectores.<br>`;
    return {h:cab+gens.map(linea).join(""),opts:soloGen!=null?[{label:"Todas las generaciones",q:"que generaciones tengo en este momento"}]:[{label:"Solo lo que está en colectores",q:"que generaciones tengo disponibles en colectores"},{label:"Solo lo que está en proceso",q:"que generaciones tengo en fermentacion"}],mem:{tipo:"gen",gen:soloGen}}; }
  function generacionesSolo(D,donde){ const arr=donde==="col"?D.enCol:D.enTanque; if(!arr.length) return {h:donde==="col"?"No hay levadura en colectores.":"No hay levadura en fermentación."};
    const cnt={}; arr.forEach(o=>{ if(!isNaN(o.gen)) (cnt[o.gen]=cnt[o.gen]||[]).push(o); });
    return {h:`En ${donde==="col"?"colectores":"fermentación"} tienes <b>${arr.length}</b> ${plural(arr.length,"unidad","unidades")}:<br>`+Object.keys(cnt).sort((a,b)=>a-b).map(g=>`<b>Gen ${g}</b>: ${cnt[g].length} <small>(${cnt[g].map(o=>donde==="col"?esc(o.nombre)+" "+o.pos:esc(o.nombre)+" "+fvTxt(D,o.tq,o.lote)).join(" · ")})</small>`).join("<br>")}; }

  /* ---------- Una levadura concreta (expediente corto con "ya se usó / en proceso") ---------- */
  function levadura(D,nombre){ const R=D.REG.filter(r=>r.nombre===nombre); const enT=D.enTanque.filter(o=>o.nombre===nombre), enC=D.enCol.filter(o=>o.nombre===nombre);
    if(!R.length&&!enT.length&&!enC.length) return null; const r=R[0], pn=parse(nombre), partes=[];
    partes.push(`<b>${esc(nombre)}</b> · ${esc(tit(pn.marca||(r&&r.marca)||""))} · familia ${esc(pn.fam||"")} · Gen ${pn.gen!=null?pn.gen:""}`);
    if(r){ const pa=padre(D,r); partes.push(`Cosechada del FV ${esc(r.tq)} (lote ${esc(r.lote)})${r.t0?" · T0 "+fmtS(parseDT(r.t0)):""}.${pa?` Viene de <b>${esc(pa.nombre)}</b>.`:""}`);
      const sie=(r.siembras||[]).map(s=>({tq:+s.tq,lote:s.lote,fecha:s.fecha})), proc=sie.filter(s=>D.lotesAct.has(s.lote)), hechas=sie.filter(s=>!D.lotesAct.has(s.lote));
      partes.push(`<span class="v33-k">Estado:</span> ${estadoTxt(r.st)}.`);
      partes.push(`<span class="v33-k">Ya se usó:</span> ${hechas.length?`en ${lst(hechas.map(s=>`FV ${s.tq} (${fmtS(parseDT(s.fecha))})`))}.`:"aún sin siembras terminadas."}`);
      partes.push(`<span class="v33-k">En proceso ahora:</span> ${proc.length?lst(proc.map(s=>`${fvTxt(D,s.tq,s.lote)}`))+".":"ninguna siembra en curso."}`);
      partes.push(`<span class="v33-k">En colector:</span> ${enC.length?lst(enC.map(o=>`${o.pos} (${hl(o.vol)})`))+".":"ya no queda en colectores."}`);
      if(r.viab!=null) partes.push(`<small>Viabilidad ${pct(r.viab)} · consistencia ${pct(r.cons)} · pH ${r.ph!=null?f(r.ph,2):"—"}</small>`); }
    else partes.push(`En proceso: ${enT.map(o=>fvTxt(D,o.tq,o.lote)).join(", ")||"—"} · En colector: ${enC.map(o=>o.pos).join(", ")||"—"}.`);
    return {h:partes.join("<br>"),mem:{tipo:"lev",nombre}}; }

  /* ---------- Linaje ---------- */
  function linaje(D,nombre){ const r=D.REG.find(x=>x.nombre===nombre); if(!r) return null; const cadena=[r]; let c=r; for(let i=0;i<8;i++){ const p=padre(D,c); if(!p||cadena.includes(p)) break; cadena.push(p); c=p; }
    return {h:`Linaje de <b>${esc(nombre)}</b> (de la más reciente a la más antigua):<br>${cadena.map(x=>`Gen ${x.generacion} · <b>${esc(x.nombre)}</b> · FV ${esc(x.tq)}${x.t0?" · "+fmtS(parseDT(x.t0)):""}`).join("<br>")}${cadena.length>=9?"<br><small>(se muestran las últimas 9 generaciones)</small>":""}`}; }

  /* ---------- Conteos por estado ---------- */
  function conteoEstados(D,filtro,etq,foco){ const R=D.REG.filter(filtro), c={}; R.forEach(r=>c[r.st]=(c[r.st]||0)+1);
    if(foco){ const n=c[foco]||0, nom={utilizada:"ya utilizadas",descartada:"descartadas",vaciada:"vaciadas sin resiembra",inventario:"disponibles en colector"}[foco]; return {h:`<b>${n}</b> cosechas ${nom} de ${R.length}${etq&&etq!=="Toda la base de datos"?" ("+etq+")":""}.<br><small>${["utilizada","inventario","vaciada","descartada","incompleto"].filter(k=>c[k]&&k!==foco).map(k=>`${estadoTxt(k)}: ${c[k]}`).join(" · ")}</small>`}; }
    const proc=D.enTanque.filter(o=>filtro({marca:o.marca,familia:o.fam,generacion:o.gen,nombre:o.nombre})).length;
    return {h:`${etq}: <b>${R.length}</b> cosechas en la base de datos.<br>${["utilizada","inventario","vaciada","descartada","incompleto"].filter(k=>c[k]).map(k=>`${estadoTxt(k)[0].toUpperCase()+estadoTxt(k).slice(1)}: <b>${c[k]}</b>`).join(" · ")}<br><span class="v33-k">En fermentación ahora:</span> <b>${proc}</b> ${plural(proc,"tanque","tanques")}.`}; }

  /* ---------- Familias en uso / ranking ---------- */
  function familiasAhora(D){ const m={}; D.enTanque.forEach(o=>{ if(!o.fam) return; const k=o.fam+"|"+o.marca; (m[k]=m[k]||{fam:o.fam,marca:o.marca,t:[],c:[]}).t.push(o); }); D.enCol.forEach(o=>{ if(!o.fam) return; const k=o.fam+"|"+o.marca; (m[k]=m[k]||{fam:o.fam,marca:o.marca,t:[],c:[]}).c.push(o); });
    const a=Object.values(m).sort((x,y)=>(y.t.length+y.c.length)-(x.t.length+x.c.length)); if(!a.length) return {h:"No hay familias en uso ahora."};
    return {h:`Hay <b>${a.length}</b> ${plural(a.length,"familia","familias")} en uso ahora:<br>`+a.map(x=>`<b>${esc(x.fam)} · ${esc(tit(x.marca))}</b>: ${x.t.length} en fermentación${x.t.length?" ("+x.t.map(o=>"FV "+o.tq).join(", ")+")":""} · ${x.c.length} en colector${x.c.length?" ("+x.c.map(o=>o.pos).join(", ")+")":""}`).join("<br>"),opts:a.slice(0,3).map(x=>({label:`Familia ${x.fam} · ${tit(x.marca)}`,q:`familia ${x.fam} ${x.marca.toLowerCase()}`}))}; }
  function familiasRanking(D){ const m={}; D.REG.forEach(r=>{ if(!r.familia||!r.marca) return; const k=r.familia+"|"+r.marca; (m[k]=m[k]||{fam:r.familia,marca:r.marca,n:0,g:0}).n++; m[k].g=Math.max(m[k].g,+r.generacion||0); });
    const a=Object.values(m).sort((x,y)=>y.n-x.n).slice(0,8); return {h:`Las familias con más cosechas en la base de datos:<br>`+a.map((x,i)=>`${i+1}. <b>${esc(x.fam)} · ${esc(tit(x.marca))}</b> — ${x.n} cosechas (hasta Gen ${x.g})`).join("<br>"),opts:a.slice(0,3).map(x=>({label:`Familia ${x.fam} · ${tit(x.marca)}`,q:`familia ${x.fam} ${x.marca.toLowerCase()}`}))}; }

  /* ---------- Memoria de la conversación ---------- */
  let mem={};
  function entidades(q){ const mf=q.match(/\bfamilia\s+(?:de\s+)?(?:la\s+|el\s+)?([a-z])\b(?!\w)/)||q.match(/\blinea\s+(?:de\s+)?(?:la\s+)?([a-z])\b(?!\w)/), mg=q.match(/\b(?:gen|generacion)\s*(\d{1,2})\b/), mm=q.match(RE_MARCA), my=q.match(/\b([a-z]{1,2}\d{1,2}f\d{1,3})\b/);
    return {fam:mf?mf[1]:null,gen:mg?+mg[1]:null,marca:mm?MARCA_PAL[mm[1]]:null,lev:my?my[1].toUpperCase():null}; }

  function responder(texto,env){ const q=Q(texto); if(!q) return null; const e=entidades(q), D=datos();
    const fvExpl=/\b(?:fv|tanque|tq|fermentador)\s*\d+/.test(q);
    const aun=/(en este momento|ahora|actualmente|hoy|ahorita|tengo|tienes|tenemos|hay)/.test(q);
    let r=null;
    // seguimiento corto: "y la j?", "y de light?", "y la gen 8?"
    const seg=q.match(/^y\s+(?:de\s+|para\s+|con\s+)?(?:la\s+|el\s+)?(?:familia\s+)?([a-z])$/);
    if(seg&&mem.tipo==="familia"&&!MARCA_PAL[seg[1]]) return withMem(familia(D,seg[1],mem.marca));
    if(/^y\s+(?:de\s+|para\s+)?(?:la\s+)?(?:gen|generacion)\s*(\d{1,2})$/.test(q)&&mem.tipo) return withMem(generacionesAhora(D,+q.match(/(\d{1,2})$/)[1]));
    if(/^y\s+(?:de\s+|para\s+|en\s+)?(light|estandar|azteca|aguila|pilsen|club colombia|club)$/.test(q)&&mem.tipo==="familia"){ return withMem(familia(D,mem.fam,MARCA_PAL[q.match(RE_MARCA)[1]])); }

    // estados globales / por filtros
    if(/\b(cuant[oa]s?)\b.*\b(utiliz|usad|use|usamos)\w*/.test(q)||/\b(descartad|vaciad)\w*/.test(q)&&/cuant|cuales|que/.test(q)){ const fl=r_=>(!e.marca||r_.marca===e.marca)&&(!e.fam||String(r_.familia).toUpperCase()===e.fam.toUpperCase())&&(e.gen==null||+r_.generacion===e.gen);
      if(!/\b(fv|tanque)\b/.test(q)) { const foco=/descartad/.test(q)?"descartada":/vaciad/.test(q)?"vaciada":/(utiliz|usad|use|usamos)/.test(q)?"utilizada":null; return withMem(conteoEstados(D,fl,[e.gen!=null?"Gen "+e.gen:"",e.fam?"familia "+e.fam.toUpperCase():"",e.marca?tit(e.marca):""].filter(Boolean).join(" · ")||"Toda la base de datos",foco)); } }
    // familia
    if(e.fam&&!e.lev&&/familia|linea/.test(q)) return withMem(familia(D,e.fam,e.marca));
    if(/\bfamilias\b/.test(q)&&!e.fam){ if(/(proceso|ahora|momento|actual|en uso|fermentando|colector)/.test(q)) return withMem(familiasAhora(D)); if(/(mas|mayor|top|principal|cuales|que familias|cuantas)/.test(q)) return withMem(/cuantas/.test(q)?{h:`Hay <b>${new Set(D.REG.map(r=>r.marca+"|"+r.familia)).size}</b> familias (marca + letra) en la base de datos; ${new Set(D.enTanque.concat(D.enCol).map(o=>o.marca+"|"+o.fam)).size} están en uso ahora.`,opts:[{label:"Cuáles están en uso",q:"que familias tengo en proceso ahora"},{label:"Las que más cosechas tienen",q:"familias con mas cosechas"}]}:(aun?familiasAhora(D):familiasRanking(D))); }
    // generaciones
    if((/\bgeneraciones\b/.test(q)||(/\bgen\b(?!\s*\d)/.test(q)&&/(tengo|tienes|tenemos|hay|cuales|que)/.test(q)))&&!fvExpl){ if(/(colector|disponible|inventario)/.test(q)&&!/(proceso|fermentac)/.test(q)) return withMem(generacionesSolo(D,"col")); if(/(proceso|fermentac|tanque|fv)/.test(q)&&!/colector/.test(q)) return withMem(generacionesSolo(D,"t")); return withMem(generacionesAhora(D)); }
    if(e.gen!=null&&!fvExpl&&!e.lev&&/(gen|generacion)/.test(q)&&/(cuant|tengo|tienes|hay|tenemos|donde|cual|que)/.test(q)){ const gA=generacionesAhora(D,e.gen); const hist=D.REG.filter(x=>+x.generacion===e.gen&&(!e.marca||x.marca===e.marca)); gA.h+=`<br><small>En la base de datos hay ${hist.length} cosechas de Gen ${e.gen} (${hist.filter(x=>x.st==="utilizada").length} ya utilizadas).</small>`; return withMem(gA); }
    // linaje
    if(e.lev&&/(viene|origen|linaje|ancestro|padre|de donde|genealog|historia de la leva)/.test(q)){ const l=linaje(D,e.lev); if(l) return withMem(l); }
    const fvLev=(()=>{ const m=q.match(/\b(?:fv|tanque|tq)\s*0*(\d{1,2})\b/); return m?D.enTanque.find(o=>o.tq===+m[1]):null; })();
    if(fvLev&&/(de donde viene|origen|linaje|ancestro|viene la levadura|de que viene)/.test(q)){ const l=linaje(D,fvLev.nombre); if(l){ l.h=`La levadura del FV ${fvLev.tq} es <b>${esc(fvLev.nombre)}</b>.<br>`+l.h; return withMem(l); } }
    // levadura concreta (expediente con "ya se uso / en proceso"), salvo preguntas puntuales que ya contesta el motor exacto
    if(e.lev&&!/(viab|consist|\bph\b|volumen|\bhl\b|cuanta|donde esta|ubic)/.test(q)){ const l=levadura(D,e.lev); if(l) return withMem(l); }
    return null; }
  function withMem(r){ if(r&&r.mem){ mem=r.mem; delete r.mem; } return r; }

  App.BotDirecto=function(texto,env){ try{ if(App.BotIA&&App.BotIA.activo()&&App.BotIA.abierta(texto)) return null; const r=responder(texto,env); if(r){ r.directo=true; return r; } }catch(e){ console.error("saber",e); } return prev(texto,env); };
  App.Saber={datos,familia:(f_,m)=>familia(datos(),f_,m),generaciones:()=>generacionesAhora(datos())};
})();
