
/* ============================================================
   chart.js — gráfico de línea interactivo
   ============================================================ */
App.Chart = (function(){
  const {esc,f} = App.U;
  const REG = {};
  function niceStep(range,n){ const raw=range/n, p=Math.pow(10,Math.floor(Math.log10(raw||1))), m=raw/p; return (m<1.5?1:m<3?2:m<7?5:10)*p; }
  function html(o){
    REG[o.id]=o; if(!o.zoom) o.zoom=null;
    return `<div class="chart" id="ch-${o.id}">${svg(o)}<div class="tip"></div><div class="row small" style="margin-top:4px"><span class="zoomhint">Arrastre sobre la gráfica para hacer zoom. Doble clic para restablecer.</span><span class="spacer"></span><button class="btn sm" type="button" data-chreset="${o.id}">Restablecer zoom</button></div>${legend(o)}</div>`;
  }
  function legend(o){ const s=o.series.filter(x=>x.n).map(x=>`<span><i style="border-color:${x.c};${x.dash?"border-top-style:dashed":""}"></i>${esc(x.n)}</span>`).join(""); return s?`<div class="legend">${s}</div>`:""; }
  function svg(o){
    const all=[].concat(...o.series.map(s=>s.pts)).filter(p=>p&&isFinite(p.x)&&isFinite(p.y));
    if(!all.length) return `<div class="empty">${esc(o.empty||"Sin datos para graficar.")}</div>`;
    const W=o.w||760, H=o.h||340, ml=o.fs?44:50, mr=18, mt=18, mb=o.fs?46:42, FS=o.fs||11;
    let x0=o.xmin!=null?o.xmin:Math.min(...all.map(p=>p.x)), x1=o.xmax!=null?o.xmax:Math.max(...all.map(p=>p.x),...(o.vlines||[]).map(v=>v.x).filter(v=>v!=null&&isFinite(v)));
    if(o.zoom){ x0=o.zoom[0]; x1=o.zoom[1]; }
    if(x1<=x0) x1=x0+1; if(!o.zoom&&o.xpad) x1+=o.xpad;
    const vis=all.filter(p=>p.x>=x0&&p.x<=x1);
    const yv=(vis.length?vis:all).map(p=>p.y).concat((o.hlines||[]).map(h=>h.y).filter(v=>v!=null&&isFinite(v)));
    let y0=Math.min(...yv), y1=Math.max(...yv); const yp=(y1-y0)*0.08||1; y0=o.ymin!=null?o.ymin:y0-yp; y1+=yp;
    const X=x=>ml+(x-x0)/(x1-x0)*(W-ml-mr), Y=y=>mt+(y1-y)/(y1-y0)*(H-mt-mb);
    o._geo={x0,x1,ml,mr,W,X,Y};
    let g=`<defs><clipPath id="cp-${o.id}"><rect x="${ml}" y="${mt}" width="${W-ml-mr}" height="${H-mt-mb}"/></clipPath></defs>`;
    const xs=o.xstep&&(x1-x0)/o.xstep<=14?o.xstep:niceStep(x1-x0,8), ys=niceStep(y1-y0,6);
    for(let x=Math.ceil(x0/xs)*xs;x<=x1+1e-9;x+=xs) g+=`<line x1="${X(x)}" x2="${X(x)}" y1="${mt}" y2="${H-mb}" stroke="var(--line-2)"/><text x="${X(x)}" y="${H-mb+15}" text-anchor="middle" font-size="${FS}" fill="var(--muted)">${o.xfmt?o.xfmt(x):Math.round(x*100)/100}</text>`;
    for(let y=Math.ceil(y0/ys)*ys;y<=y1+1e-9;y+=ys) g+=`<line x1="${ml}" x2="${W-mr}" y1="${Y(y)}" y2="${Y(y)}" stroke="var(--line-2)"/><text x="${ml-6}" y="${Y(y)+4}" text-anchor="end" font-size="${FS}" fill="var(--muted)">${Math.round(y*100)/100}</text>`;
    if(o.xlab) g+=`<text x="${(W+ml)/2}" y="${H-5}" text-anchor="middle" font-size="${FS}" fill="var(--muted)">${esc(o.xlab)}</text>`;
    if(o.ylab) g+=`<text transform="translate(12 ${(H-mb+mt)/2}) rotate(-90)" text-anchor="middle" font-size="${FS}" fill="var(--muted)">${esc(o.ylab)}</text>`;
    let c=`<g clip-path="url(#cp-${o.id})">`;
    (o.hlines||[]).forEach(h=>{ if(h.y==null||!isFinite(h.y)) return; c+=`<line x1="${ml}" x2="${W-mr}" y1="${Y(h.y)}" y2="${Y(h.y)}" stroke="${h.c}" stroke-width="1.3" stroke-dasharray="5 4"/><text x="${ml+6}" y="${Y(h.y)-4}" text-anchor="start" font-size="${FS}" font-weight="600" fill="${h.c}" paint-order="stroke" stroke="var(--surface)" stroke-width="3">${esc(h.l)}</text>`; });
    (o.vlines||[]).forEach(v=>{ if(v.x==null||!isFinite(v.x)||v.x<x0||v.x>x1) return; c+=`<line x1="${X(v.x)}" x2="${X(v.x)}" y1="${mt}" y2="${H-mb}" stroke="${v.c}" stroke-width="${v.w||1.5}" ${v.dash?'stroke-dasharray="4 4"':""}/><text x="${X(v.x)+4}" y="${mt+12+(v.dy||0)}" font-size="${FS}" font-weight="600" fill="${v.c}" paint-order="stroke" stroke="var(--surface)" stroke-width="3">${esc(v.l)}</text>`; });
    o.series.forEach(s=>{ const pts=s.pts.filter(p=>p&&isFinite(p.x)&&isFinite(p.y));
      if(s.bars){ const bw=Math.max(3,(W-ml-mr)/((x1-x0)||1)*0.7); pts.forEach(p=>{ const yb=Y(Math.max(y0,0)); c+=`<rect x="${X(p.x)-bw/2}" y="${Math.min(Y(p.y),yb)}" width="${bw}" height="${Math.abs(yb-Y(p.y))}" fill="${p.c||s.c}"/>`; }); return; }
      if(pts.length>1&&s.line!==false) c+=`<polyline points="${pts.map(p=>X(p.x)+","+Y(p.y)).join(" ")}" fill="none" stroke="${s.c}" stroke-width="${s.w||2.2}" ${s.dash?'stroke-dasharray="7 5"':""} stroke-linejoin="round"/>`;
      if(s.dots!==false) pts.forEach(p=>{ c+=`<circle cx="${X(p.x)}" cy="${Y(p.y)}" r="${s.r||4}" fill="${s.hollow||p.hollow?"var(--surface)":s.c}" stroke="${s.c}" stroke-width="2"/>`; });
    });
    c+=`</g><rect class="sel" x="0" y="${mt}" width="0" height="${H-mt-mb}" fill="var(--accent)" opacity=".12"/><line class="cur" x1="0" x2="0" y1="${mt}" y2="${H-mb}" stroke="var(--muted)" stroke-dasharray="2 3" opacity="0"/>`;
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.title||"Gráfica")}" data-chart="${o.id}">${g}${c}</svg>`;
  }
  function redraw(id){ const o=REG[id], el=document.getElementById("ch-"+id); if(!o||!el) return; el.querySelector("svg,.empty").outerHTML=svg(o); }
  function toX(o,svgEl,clientX){ const r=svgEl.getBoundingClientRect(), g=o._geo, vx=(clientX-r.left)/r.width*g.W; return {vx,x:g.x0+(vx-g.ml)/(g.W-g.ml-g.mr)*(g.x1-g.x0)}; }
  let drag=null;
  document.addEventListener("pointerdown",e=>{ const s=e.target.closest&&e.target.closest("svg[data-chart]"); if(!s) return; const o=REG[s.dataset.chart]; if(!o||!o._geo) return; drag={s,o,a:toX(o,s,e.clientX)}; });
  document.addEventListener("pointermove",e=>{
    const s=e.target.closest&&e.target.closest("svg[data-chart]");
    if(drag){ const b=toX(drag.o,drag.s,e.clientX), r=drag.s.querySelector("rect.sel"); r.setAttribute("x",Math.min(drag.a.vx,b.vx)); r.setAttribute("width",Math.abs(b.vx-drag.a.vx)); return; }
    if(!s) return; const o=REG[s.dataset.chart]; if(!o||!o._geo) return; const p=toX(o,s,e.clientX), g=o._geo;
    let best=null,bd=Infinity; o.series.forEach(se=>se.pts.forEach(pt=>{ if(!pt||!pt.tip||!isFinite(pt.x)) return; const d=Math.abs(g.X(pt.x)-p.vx); if(d<bd){bd=d;best={pt,se};} }));
    const tip=s.parentNode.querySelector(".tip"), cur=s.querySelector("line.cur");
    if(best&&bd<24){ const r=s.getBoundingClientRect(), sc=r.width/g.W; tip.innerHTML=best.pt.tip; tip.style.display="block"; tip.style.left=(g.X(best.pt.x)*sc)+"px"; tip.style.top=(g.Y(best.pt.y)*sc)+"px"; cur.setAttribute("x1",g.X(best.pt.x)); cur.setAttribute("x2",g.X(best.pt.x)); cur.setAttribute("opacity","1"); }
    else { tip.style.display="none"; cur.setAttribute("opacity","0"); }
  });
  document.addEventListener("pointerup",e=>{ if(!drag) return; const d=drag; drag=null; const b=toX(d.o,d.s,e.clientX);
    if(Math.abs(b.vx-d.a.vx)>12){ d.o.zoom=[Math.min(d.a.x,b.x),Math.max(d.a.x,b.x)]; redraw(d.o.id); } else { const r=d.s.querySelector("rect.sel"); r&&r.setAttribute("width",0); } });
  document.addEventListener("pointerleave",()=>{ drag=null; });
  document.addEventListener("pointerout",e=>{
    const s=e.target.closest&&e.target.closest("svg[data-chart]"); if(!s) return;
    if(s.contains(e.relatedTarget)) return;
    const tip=s.parentNode.querySelector(".tip"); if(tip) tip.style.display="none";
    const cur=s.querySelector("line.cur"); if(cur) cur.setAttribute("opacity","0");
  },true);
  document.addEventListener("dblclick",e=>{ const s=e.target.closest&&e.target.closest("svg[data-chart]"); if(!s) return; const o=REG[s.dataset.chart]; o.zoom=null; redraw(o.id); });
  document.addEventListener("click",e=>{ const b=e.target.closest&&e.target.closest("[data-chreset]"); if(!b) return; const o=REG[b.dataset.chreset]; if(o){ o.zoom=null; redraw(o.id); } });
  return {html};
})();
